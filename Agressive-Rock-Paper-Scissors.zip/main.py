import getpass
def pee():
  print ("Welcome to rock paper scissors you person.\n")
  player1 = getpass.getpass("Enter rock, paper, or scissors.")
  player2 = input ("Enter rock, paper, or scissors.")
  if player1==player2: 
    print("Its a tie from both players. Get smarter next time you apes. I think you both may have an IQ lower than an average antivax baby's life expectancy.")
  elif player1== "rock":
    if player2== "scissors":
      print ("Player 1 wins with rock. Player 2 what happened? You had them on the ropes.")
    elif player2== "paper":
      print ("Player 2 wins with paper. Player 1 you smell git gud.")
    else:
      print("Player 1 or 2 your answer was not understood. Try again you simpleminded mouth breather.")
  elif player1== "paper":
    if player2== "scissors":
      print ("Player 2 wins, player 1 you stink. I expected better from you. no just kidding, I had no faith to begin with.")
    elif player2== "rock":
      print ("Player 1 wins with paper, try again player 2, you suck.")
    else:
      print ("Player 1 or 2 your answer was not understood try normal english this time.")
  elif player1== "scissors":
    if player2== "paper":
      print ("Player 1 wins with scissors, player 2 you simple minded fool how could you let this happen. You are better than this. Oh well WOOOOOOO PLAYER 1 FOR THE WIN, PLAYER 2 TRY AGAIN NOT WINNER.")
    elif player2== "rock":
      print ("Hey player 1 you lost, try again. Some advice though, stink less next time.")
    else:
      print ("Ok which one of you players typed something dumb? Player 2 I'm looking at you.")
  re = "poo"
  while (re != "yes" and re != "no"):
    re = input ("Would you like to play again? Please don't I am waiting for better players.  ")
    if re == "yes":
      print ("\nDamn it, I'll never find any better players now. Fine enjoy your game of agressive rock, paper, scissors.")
      pee()
    elif re == "no":
      print ("Game over, thank god too. I can finally find some better players to entertain me.")
    else:
      print ("You only have those two choices fool, nothing else will work.")
pee()